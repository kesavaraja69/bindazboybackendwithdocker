--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bindazboyappdb;
--
-- Name: bindazboyappdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bindazboyappdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE bindazboyappdb OWNER TO postgres;

\connect bindazboyappdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.admin (
    admin_id integer NOT NULL,
    admin_email character varying NOT NULL,
    admin_password character varying NOT NULL
);


ALTER TABLE public.admin OWNER TO ubuntu;

--
-- Name: admin_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.admin_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_admin_id_seq OWNER TO ubuntu;

--
-- Name: admin_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.admin_admin_id_seq OWNED BY public.admin.admin_id;


--
-- Name: audiobooks; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.audiobooks (
    audiobook_id integer NOT NULL,
    audiobook_title character varying NOT NULL,
    audiobook_description character varying NOT NULL,
    audiobook_imagecover character varying NOT NULL,
    audiobook_author character varying NOT NULL,
    audiobook_date date
);


ALTER TABLE public.audiobooks OWNER TO ubuntu;

--
-- Name: audiobooks_audiobook_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.audiobooks_audiobook_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audiobooks_audiobook_id_seq OWNER TO ubuntu;

--
-- Name: audiobooks_audiobook_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.audiobooks_audiobook_id_seq OWNED BY public.audiobooks.audiobook_id;


--
-- Name: audiobookschapter; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.audiobookschapter (
    audiobookchapter_id integer NOT NULL,
    audiobookchapter_title character varying NOT NULL,
    audiobookchapter_description character varying NOT NULL,
    audiobookchapter_audiourl character varying NOT NULL,
    "audiobooksAudiobookId" integer
);


ALTER TABLE public.audiobookschapter OWNER TO ubuntu;

--
-- Name: audiobookschapter_audiobookchapter_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.audiobookschapter_audiobookchapter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audiobookschapter_audiobookchapter_id_seq OWNER TO ubuntu;

--
-- Name: audiobookschapter_audiobookchapter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.audiobookschapter_audiobookchapter_id_seq OWNED BY public.audiobookschapter.audiobookchapter_id;


--
-- Name: blogs; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.blogs (
    blog_id integer NOT NULL,
    blog_title character varying NOT NULL,
    blog_description character varying NOT NULL,
    blog_image character varying NOT NULL,
    blog_view character varying,
    blog_category character varying NOT NULL,
    blog_audio character varying,
    blog_images text,
    blog_date date,
    "catergorysCatergoryId" integer
);


ALTER TABLE public.blogs OWNER TO ubuntu;

--
-- Name: blogs_blog_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.blogs_blog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blogs_blog_id_seq OWNER TO ubuntu;

--
-- Name: blogs_blog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.blogs_blog_id_seq OWNED BY public.blogs.blog_id;


--
-- Name: bookmark_blog; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.bookmark_blog (
    bookmark_id integer NOT NULL,
    "bookmarkBlogdataBlogId" integer,
    "bookmarkUserId" integer
);


ALTER TABLE public.bookmark_blog OWNER TO ubuntu;

--
-- Name: bookmark_blog_bookmark_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.bookmark_blog_bookmark_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookmark_blog_bookmark_id_seq OWNER TO ubuntu;

--
-- Name: bookmark_blog_bookmark_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.bookmark_blog_bookmark_id_seq OWNED BY public.bookmark_blog.bookmark_id;


--
-- Name: catergory; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.catergory (
    catergory_id integer NOT NULL,
    catergory_title character varying NOT NULL
);


ALTER TABLE public.catergory OWNER TO ubuntu;

--
-- Name: catergory_catergory_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.catergory_catergory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catergory_catergory_id_seq OWNER TO ubuntu;

--
-- Name: catergory_catergory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.catergory_catergory_id_seq OWNED BY public.catergory.catergory_id;


--
-- Name: contactus; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.contactus (
    contactus_id integer NOT NULL,
    contactus_date timestamp without time zone DEFAULT ('now'::text)::timestamp(6) with time zone NOT NULL,
    contactus_name character varying NOT NULL,
    iscontactus character varying NOT NULL,
    contactus_email character varying NOT NULL,
    contactus_message character varying NOT NULL,
    "logUserId" integer
);


ALTER TABLE public.contactus OWNER TO ubuntu;

--
-- Name: contactus_contactus_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.contactus_contactus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contactus_contactus_id_seq OWNER TO ubuntu;

--
-- Name: contactus_contactus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.contactus_contactus_id_seq OWNED BY public.contactus.contactus_id;


--
-- Name: forgotpassword; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.forgotpassword (
    forgotid integer NOT NULL,
    email character varying,
    otp character varying,
    crt_date character varying,
    exp_date character varying,
    "userId" integer
);


ALTER TABLE public.forgotpassword OWNER TO ubuntu;

--
-- Name: forgotpassword_forgotid_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.forgotpassword_forgotid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forgotpassword_forgotid_seq OWNER TO ubuntu;

--
-- Name: forgotpassword_forgotid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.forgotpassword_forgotid_seq OWNED BY public.forgotpassword.forgotid;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO ubuntu;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO ubuntu;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: typeorm_metadata; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.typeorm_metadata (
    type character varying NOT NULL,
    database character varying,
    schema character varying,
    "table" character varying,
    name character varying,
    value text
);


ALTER TABLE public.typeorm_metadata OWNER TO ubuntu;

--
-- Name: users; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.users (
    id integer NOT NULL,
    useremail character varying NOT NULL,
    username character varying,
    userpassword character varying NOT NULL
);


ALTER TABLE public.users OWNER TO ubuntu;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO ubuntu;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: userzoom; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.userzoom (
    "zoomUserId" integer NOT NULL,
    "zoomMeetUser" character varying NOT NULL,
    "zoomMeetUserEmail" character varying NOT NULL,
    "zoomdtZoomId" integer,
    user_date character varying
);


ALTER TABLE public.userzoom OWNER TO ubuntu;

--
-- Name: userzoom_zoomUserId_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public."userzoom_zoomUserId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."userzoom_zoomUserId_seq" OWNER TO ubuntu;

--
-- Name: userzoom_zoomUserId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public."userzoom_zoomUserId_seq" OWNED BY public.userzoom."zoomUserId";


--
-- Name: view; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.view (
    view_id integer NOT NULL,
    view_date timestamp without time zone DEFAULT ('now'::text)::timestamp(6) with time zone NOT NULL,
    "viewPostBlogId" integer,
    "viewsUserId" integer
);


ALTER TABLE public.view OWNER TO ubuntu;

--
-- Name: view_view_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.view_view_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.view_view_id_seq OWNER TO ubuntu;

--
-- Name: view_view_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.view_view_id_seq OWNED BY public.view.view_id;


--
-- Name: zoom; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.zoom (
    "zoomId" integer NOT NULL,
    regsiter_date timestamp without time zone DEFAULT ('now'::text)::timestamp(6) with time zone NOT NULL,
    "zoomMeetId" character varying NOT NULL,
    "zoomMeetTopic" character varying,
    "zoomMeetPassword" character varying NOT NULL,
    zoommeetdateandtime character varying,
    zoommeetupcomingdate character varying,
    "zoom_Available_Slots" integer,
    "zoom_Total_Slots" integer NOT NULL,
    "zoommeetURL" character varying NOT NULL,
    "zoomMeetIsEnable" character varying
);


ALTER TABLE public.zoom OWNER TO ubuntu;

--
-- Name: zoom_zoomId_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public."zoom_zoomId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."zoom_zoomId_seq" OWNER TO ubuntu;

--
-- Name: zoom_zoomId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public."zoom_zoomId_seq" OWNED BY public.zoom."zoomId";


--
-- Name: admin admin_id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.admin ALTER COLUMN admin_id SET DEFAULT nextval('public.admin_admin_id_seq'::regclass);


--
-- Name: audiobooks audiobook_id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.audiobooks ALTER COLUMN audiobook_id SET DEFAULT nextval('public.audiobooks_audiobook_id_seq'::regclass);


--
-- Name: audiobookschapter audiobookchapter_id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.audiobookschapter ALTER COLUMN audiobookchapter_id SET DEFAULT nextval('public.audiobookschapter_audiobookchapter_id_seq'::regclass);


--
-- Name: blogs blog_id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.blogs ALTER COLUMN blog_id SET DEFAULT nextval('public.blogs_blog_id_seq'::regclass);


--
-- Name: bookmark_blog bookmark_id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.bookmark_blog ALTER COLUMN bookmark_id SET DEFAULT nextval('public.bookmark_blog_bookmark_id_seq'::regclass);


--
-- Name: catergory catergory_id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.catergory ALTER COLUMN catergory_id SET DEFAULT nextval('public.catergory_catergory_id_seq'::regclass);


--
-- Name: contactus contactus_id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.contactus ALTER COLUMN contactus_id SET DEFAULT nextval('public.contactus_contactus_id_seq'::regclass);


--
-- Name: forgotpassword forgotid; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.forgotpassword ALTER COLUMN forgotid SET DEFAULT nextval('public.forgotpassword_forgotid_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: userzoom zoomUserId; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.userzoom ALTER COLUMN "zoomUserId" SET DEFAULT nextval('public."userzoom_zoomUserId_seq"'::regclass);


--
-- Name: view view_id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.view ALTER COLUMN view_id SET DEFAULT nextval('public.view_view_id_seq'::regclass);


--
-- Name: zoom zoomId; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.zoom ALTER COLUMN "zoomId" SET DEFAULT nextval('public."zoom_zoomId_seq"'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.admin (admin_id, admin_email, admin_password) FROM stdin;
\.
COPY public.admin (admin_id, admin_email, admin_password) FROM '$$PATH$$/3441.dat';

--
-- Data for Name: audiobooks; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.audiobooks (audiobook_id, audiobook_title, audiobook_description, audiobook_imagecover, audiobook_author, audiobook_date) FROM stdin;
\.
COPY public.audiobooks (audiobook_id, audiobook_title, audiobook_description, audiobook_imagecover, audiobook_author, audiobook_date) FROM '$$PATH$$/3445.dat';

--
-- Data for Name: audiobookschapter; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.audiobookschapter (audiobookchapter_id, audiobookchapter_title, audiobookchapter_description, audiobookchapter_audiourl, "audiobooksAudiobookId") FROM stdin;
\.
COPY public.audiobookschapter (audiobookchapter_id, audiobookchapter_title, audiobookchapter_description, audiobookchapter_audiourl, "audiobooksAudiobookId") FROM '$$PATH$$/3443.dat';

--
-- Data for Name: blogs; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.blogs (blog_id, blog_title, blog_description, blog_image, blog_view, blog_category, blog_audio, blog_images, blog_date, "catergorysCatergoryId") FROM stdin;
\.
COPY public.blogs (blog_id, blog_title, blog_description, blog_image, blog_view, blog_category, blog_audio, blog_images, blog_date, "catergorysCatergoryId") FROM '$$PATH$$/3433.dat';

--
-- Data for Name: bookmark_blog; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.bookmark_blog (bookmark_id, "bookmarkBlogdataBlogId", "bookmarkUserId") FROM stdin;
\.
COPY public.bookmark_blog (bookmark_id, "bookmarkBlogdataBlogId", "bookmarkUserId") FROM '$$PATH$$/3435.dat';

--
-- Data for Name: catergory; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.catergory (catergory_id, catergory_title) FROM stdin;
\.
COPY public.catergory (catergory_id, catergory_title) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: contactus; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.contactus (contactus_id, contactus_date, contactus_name, iscontactus, contactus_email, contactus_message, "logUserId") FROM stdin;
\.
COPY public.contactus (contactus_id, contactus_date, contactus_name, iscontactus, contactus_email, contactus_message, "logUserId") FROM '$$PATH$$/3437.dat';

--
-- Data for Name: forgotpassword; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.forgotpassword (forgotid, email, otp, crt_date, exp_date, "userId") FROM stdin;
\.
COPY public.forgotpassword (forgotid, email, otp, crt_date, exp_date, "userId") FROM '$$PATH$$/3449.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
\.
COPY public.migrations (id, "timestamp", name) FROM '$$PATH$$/3447.dat';

--
-- Data for Name: typeorm_metadata; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.typeorm_metadata (type, database, schema, "table", name, value) FROM stdin;
\.
COPY public.typeorm_metadata (type, database, schema, "table", name, value) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.users (id, useremail, username, userpassword) FROM stdin;
\.
COPY public.users (id, useremail, username, userpassword) FROM '$$PATH$$/3439.dat';

--
-- Data for Name: userzoom; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.userzoom ("zoomUserId", "zoomMeetUser", "zoomMeetUserEmail", "zoomdtZoomId", user_date) FROM stdin;
\.
COPY public.userzoom ("zoomUserId", "zoomMeetUser", "zoomMeetUserEmail", "zoomdtZoomId", user_date) FROM '$$PATH$$/3451.dat';

--
-- Data for Name: view; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.view (view_id, view_date, "viewPostBlogId", "viewsUserId") FROM stdin;
\.
COPY public.view (view_id, view_date, "viewPostBlogId", "viewsUserId") FROM '$$PATH$$/3431.dat';

--
-- Data for Name: zoom; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.zoom ("zoomId", regsiter_date, "zoomMeetId", "zoomMeetTopic", "zoomMeetPassword", zoommeetdateandtime, zoommeetupcomingdate, "zoom_Available_Slots", "zoom_Total_Slots", "zoommeetURL", "zoomMeetIsEnable") FROM stdin;
\.
COPY public.zoom ("zoomId", regsiter_date, "zoomMeetId", "zoomMeetTopic", "zoomMeetPassword", zoommeetdateandtime, zoommeetupcomingdate, "zoom_Available_Slots", "zoom_Total_Slots", "zoommeetURL", "zoomMeetIsEnable") FROM '$$PATH$$/3453.dat';

--
-- Name: admin_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.admin_admin_id_seq', 1, true);


--
-- Name: audiobooks_audiobook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.audiobooks_audiobook_id_seq', 1, false);


--
-- Name: audiobookschapter_audiobookchapter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.audiobookschapter_audiobookchapter_id_seq', 1, false);


--
-- Name: blogs_blog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.blogs_blog_id_seq', 61, true);


--
-- Name: bookmark_blog_bookmark_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.bookmark_blog_bookmark_id_seq', 86, true);


--
-- Name: catergory_catergory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.catergory_catergory_id_seq', 3, true);


--
-- Name: contactus_contactus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.contactus_contactus_id_seq', 6, true);


--
-- Name: forgotpassword_forgotid_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.forgotpassword_forgotid_seq', 62, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.migrations_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.users_id_seq', 146, true);


--
-- Name: userzoom_zoomUserId_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public."userzoom_zoomUserId_seq"', 26, true);


--
-- Name: view_view_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.view_view_id_seq', 1638, true);


--
-- Name: zoom_zoomId_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public."zoom_zoomId_seq"', 1, true);


--
-- Name: admin PK_08603203f2c50664bda27b1ff89; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT "PK_08603203f2c50664bda27b1ff89" PRIMARY KEY (admin_id);


--
-- Name: zoom PK_2a2701f30e3255978bd46991138; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.zoom
    ADD CONSTRAINT "PK_2a2701f30e3255978bd46991138" PRIMARY KEY ("zoomId");


--
-- Name: userzoom PK_3c6741a8df0d7b9036083158790; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.userzoom
    ADD CONSTRAINT "PK_3c6741a8df0d7b9036083158790" PRIMARY KEY ("zoomUserId");


--
-- Name: view PK_4cd8b7ba393d20320a628206260; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.view
    ADD CONSTRAINT "PK_4cd8b7ba393d20320a628206260" PRIMARY KEY (view_id);


--
-- Name: audiobooks PK_5a837674bb04c6774a7c1167fa0; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.audiobooks
    ADD CONSTRAINT "PK_5a837674bb04c6774a7c1167fa0" PRIMARY KEY (audiobook_id);


--
-- Name: contactus PK_5e806f061a0af160413f4e2cb59; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.contactus
    ADD CONSTRAINT "PK_5e806f061a0af160413f4e2cb59" PRIMARY KEY (contactus_id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: blogs PK_9728ee7386486ed6752b06983e8; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.blogs
    ADD CONSTRAINT "PK_9728ee7386486ed6752b06983e8" PRIMARY KEY (blog_id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: audiobookschapter PK_b39f2118789b82d8dd339efa4e6; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.audiobookschapter
    ADD CONSTRAINT "PK_b39f2118789b82d8dd339efa4e6" PRIMARY KEY (audiobookchapter_id);


--
-- Name: catergory PK_c6a2a328fbb90a8e7e64ae74895; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.catergory
    ADD CONSTRAINT "PK_c6a2a328fbb90a8e7e64ae74895" PRIMARY KEY (catergory_id);


--
-- Name: bookmark_blog PK_f4b5a0fd358faf41c96da93645b; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.bookmark_blog
    ADD CONSTRAINT "PK_f4b5a0fd358faf41c96da93645b" PRIMARY KEY (bookmark_id);


--
-- Name: forgotpassword PK_fe079876a51b442551e5cb7d577; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.forgotpassword
    ADD CONSTRAINT "PK_fe079876a51b442551e5cb7d577" PRIMARY KEY (forgotid);


--
-- Name: forgotpassword REL_f2ed51212b8062dc0945cdd9bc; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.forgotpassword
    ADD CONSTRAINT "REL_f2ed51212b8062dc0945cdd9bc" UNIQUE ("userId");


--
-- Name: bookmark_blog FK_060ceca065260a877f656f22550; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.bookmark_blog
    ADD CONSTRAINT "FK_060ceca065260a877f656f22550" FOREIGN KEY ("bookmarkBlogdataBlogId") REFERENCES public.blogs(blog_id);


--
-- Name: blogs FK_11345203072c49ec963295a8d59; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.blogs
    ADD CONSTRAINT "FK_11345203072c49ec963295a8d59" FOREIGN KEY ("catergorysCatergoryId") REFERENCES public.catergory(catergory_id);


--
-- Name: bookmark_blog FK_20fe05122379b0af1792d528382; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.bookmark_blog
    ADD CONSTRAINT "FK_20fe05122379b0af1792d528382" FOREIGN KEY ("bookmarkUserId") REFERENCES public.users(id);


--
-- Name: contactus FK_583c5b69afe423562bcd15b2754; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.contactus
    ADD CONSTRAINT "FK_583c5b69afe423562bcd15b2754" FOREIGN KEY ("logUserId") REFERENCES public.users(id);


--
-- Name: view FK_bb257dd82d87e798f10d5b8bc23; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.view
    ADD CONSTRAINT "FK_bb257dd82d87e798f10d5b8bc23" FOREIGN KEY ("viewPostBlogId") REFERENCES public.blogs(blog_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: userzoom FK_cdc108fc4a4856743f9633a1c07; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.userzoom
    ADD CONSTRAINT "FK_cdc108fc4a4856743f9633a1c07" FOREIGN KEY ("zoomdtZoomId") REFERENCES public.zoom("zoomId");


--
-- Name: forgotpassword FK_f2ed51212b8062dc0945cdd9bc4; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.forgotpassword
    ADD CONSTRAINT "FK_f2ed51212b8062dc0945cdd9bc4" FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: audiobookschapter FK_f592c9b586ffe11bbb98d936320; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.audiobookschapter
    ADD CONSTRAINT "FK_f592c9b586ffe11bbb98d936320" FOREIGN KEY ("audiobooksAudiobookId") REFERENCES public.audiobooks(audiobook_id);


--
-- Name: view FK_f8b213660f06653c08755300abf; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.view
    ADD CONSTRAINT "FK_f8b213660f06653c08755300abf" FOREIGN KEY ("viewsUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

